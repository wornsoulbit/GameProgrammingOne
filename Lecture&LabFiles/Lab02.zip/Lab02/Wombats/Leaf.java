// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import greenfoot.*;

/**
 * Leaf - a class for representing leaves.
 * @author Michael Kölling @version 2.0
 */
public class Leaf extends Actor
{

    /* (World, Actor, GreenfootImage, and Greenfoot)*/

    /**
     * 
     */
    public Leaf()
    {
    }
}
